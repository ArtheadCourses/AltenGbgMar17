from ..data_model.User import *


def process(data):
    print("Creating user from model")
    u = User()
    c = Company()
    print('Processing', data)

