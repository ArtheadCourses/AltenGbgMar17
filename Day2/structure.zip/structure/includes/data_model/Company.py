class Company:
    pass