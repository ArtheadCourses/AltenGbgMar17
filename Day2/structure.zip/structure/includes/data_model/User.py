class User:
    pass