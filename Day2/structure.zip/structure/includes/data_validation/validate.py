def validate(data):
    print('Validating', data)