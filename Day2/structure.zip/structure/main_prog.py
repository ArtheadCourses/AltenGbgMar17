from includes.data_proc.process import process

def main():
    process('Allan')


if __name__ == '__main__':
    main()